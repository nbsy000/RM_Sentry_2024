#ifndef __USART1_H__
#define __USART1_H__
#define RX_USART1_BUFFER 30

void USART1_Configuration(void);
void RC_Rst(void);
#endif
