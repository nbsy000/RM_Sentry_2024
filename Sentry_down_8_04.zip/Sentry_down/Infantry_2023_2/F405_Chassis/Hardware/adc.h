#ifndef __ADC_H
#define __ADC_H

void ADC_Configuration(void);
void ADC_Filter(void);

#endif 


