#ifndef __TIM2_H
#define __TIM2_H

void TIM2_Configuration(void);
void delay_ms(int n);

#endif
