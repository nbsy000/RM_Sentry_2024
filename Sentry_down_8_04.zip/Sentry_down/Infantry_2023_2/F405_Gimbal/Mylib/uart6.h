#ifndef _UART6_H_
#define _UART6_H_
#define PC_SENDBUF_SIZE 16    //20
#define PC_RECVBUF_SIZE 9
void USART6_Configuration(void);


#endif
