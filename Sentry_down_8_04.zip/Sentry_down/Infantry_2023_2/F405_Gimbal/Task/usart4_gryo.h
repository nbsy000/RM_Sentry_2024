#ifndef __USART4_H__
#define __USART4_H__

void UART4_Configuration(void);
void RC_Rst(void);
#endif

