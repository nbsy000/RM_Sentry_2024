#ifndef __CONTROLTASK_H__
#define __CONTROLTASK_H__

#include "main.h"

void Control_task(void *pvParameters);

#endif
